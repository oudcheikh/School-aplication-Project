

import json

class LOADCONFIG:


    def __init__(self):

        self.config_file =''
        self.data = ''


    def _loadparam(self, config_file):

        with open(self.config_file) as data_file:
            self.data = json.load(data_file)
        return self.data


    def getDBname(self):

        return self.data['dataBase']['database']

    def getDBserver(self):

        return self.data['dataBase']['server']


    def getDBport(self):

        return self.data['dataBase']['port']


    def getDBuser(self):

        return self.data['dataBase']['user']


    def getDBpassword(self):

        return self.data['dataBase']['password']

