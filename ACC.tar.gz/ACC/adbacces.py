
import json


config_file = 'CONFIG.json'



print (data['mysql']['database'])
print (data['mysql']['server'])
print (data['mysql']['port'])
print (data['mysql']['user'])
print (data['mysql']['password'])

data_file.close()
